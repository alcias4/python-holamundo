"""
Esta es la documentacion de player
"""


class Player:
    """
    La clase del reproductor
    """
    def play(self, song):
        """
        Reproduce la cancion

        Parameters:
        song (str): este es un string con el path de la cacione

        Return: 
        int: Delvuelve 1 si repdroduce con exito sino 0.
        """
        print('reproducciendo cancion')
    
    def stop(self):
        print("stopping")
